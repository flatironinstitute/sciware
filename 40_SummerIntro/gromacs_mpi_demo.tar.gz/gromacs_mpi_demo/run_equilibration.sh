#!/bin/bash

# Run on the Rome nodes at Flatiron
#SBATCH --job-name=gromacs_example_equilibration
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=30
#SBATCH --cpus-per-task=4
#SBATCH --constraint=rome
#SBATCH --partition=ccb
#SBATCH --time=02:00:00

# Set up our modules
module -q purge
module -q load modules/2.3-20240529
module -q load openmpi/cuda-4.0.7
module -q load plumed/mpi-2.9.1
module -q load gromacs/mpi-plumed-2023

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK


# This is an attempt at getting the GROMACS equilibration of the membrane right
minit=step5_input
rest_prefix=step5_input
mini_prefix=step6.0_minimization
equi_prefix=step6.%d_equilibration
prod_prefix=step7_production
prod_step=step7

# Get some CPU information
lscpu

# See if we can run the precursor steps
mpirun -np 1 gmx_mpi grompp -f ${mini_prefix}.mdp -o ${mini_prefix}.tpr -c ${minit}.gro -r ${rest_prefix}.gro -p topol.top -n index.ndx
mpirun --map-by socket:pe=$OMP_NUM_THREADS gmx_mpi mdrun -v -deffnm ${mini_prefix}

# Equilibration only!
let cnt=1
let cntmax=6

while [ $cnt -le $cntmax ] ; do
  pcnt=$((cnt-1))
  istep=`printf ${equi_prefix} ${cnt}`
  pstep=`printf ${equi_prefix} ${pcnt}`

  if [ $cnt -eq 1 ]
  then
    pstep=${mini_prefix}
  fi
  mpirun -np 1 gmx_mpi grompp -f ${istep}.mdp -o ${istep}.tpr -c ${pstep}.gro -r ${rest_prefix}.gro -p topol.top -n index.ndx -maxwarn 2
  mpirun --map-by socket:pe=$OMP_NUM_THREADS gmx_mpi mdrun -v -deffnm ${istep}
  ((cnt++))
done






